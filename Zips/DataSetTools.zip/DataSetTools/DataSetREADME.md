# DataSetTools

## Overview
`DataSetTools` is a Python module designed to perform basic statistical analysis on a dataset. It provides functionalities to calculate the mean, median, mode, and range of a list of numbers.

## Features
- **Mean**: Calculates the average of the dataset.
- **Median**: Finds the middle value of the dataset.
- **Mode**: Identifies the most frequently occurring value in the dataset.
- **Range**: Computes the difference between the maximum and minimum values in the dataset.

## Usage
To use the `DataSetTools` module, create an instance of the `DataSet` class with a list of integers and call the desired methods.

### Example
```python
from DataSetTools import DataSet

numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
data = DataSet(numbers)

print(f"Mean: {data.mean()}")
print(f"Median: {data.median()}")
print(f"Mode: {data.mode()}")
print(f"Range: {data.range()}")
```

## Installation
Simply download the `DataSetTools.py` file and include it in your project directory.

## License
This project is licensed under the MIT License.